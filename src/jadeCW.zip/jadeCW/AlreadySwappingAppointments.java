package jadeCW;


import jade.content.Predicate;

public class AlreadySwappingAppointments implements Predicate {
}
