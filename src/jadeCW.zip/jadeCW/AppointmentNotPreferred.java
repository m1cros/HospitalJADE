package jadeCW;

import jade.content.Predicate;

public class AppointmentNotPreferred implements Predicate {
}
